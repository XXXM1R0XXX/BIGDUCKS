package main

import(
	"fmt"
	"net/http"
	"database/sql"
	"encoding/json"

	_ "github.com/go-sql-driver/mysql"
)

type Location struct{
	Latitude float64
	Longitude float64
}
func main() {
  http.HandleFunc("/api/get/", func(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Access-Control-Allow-Origin", "*")
	db, _ := sql.Open("mysql", "root:1234@tcp(database:3306)/taxi")
	result, _ := db.Query("SELECT `latitube1`, `longitube1` FROM `passajirs`")
	locations := []Location{}
	for result.Next(){
		location := Location{}
		result.Scan(&location.Latitude, &location.Longitude)
		locations = append(locations, location)
	}
	datajson,_ := json.Marshal(locations)
	fmt.Fprintf(w, string(datajson))
  })
  http.ListenAndServe(":8000", nil)
}