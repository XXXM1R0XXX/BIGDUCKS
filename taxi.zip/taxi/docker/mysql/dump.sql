--
-- Файл сгенерирован с помощью SQLiteStudio v3.3.3 в Сб сен 10 15:45:52 2022
--
-- Использованная кодировка текста: System
--

-- Таблица: passajirs
DROP TABLE IF EXISTS passajirs;

CREATE TABLE passajirs (
    latitube1   DOUBLE,
    longitube1  DOUBLE,
    chat_id1    INTEGER UNIQUE
                        NOT NULL,
    message_id1 INTEGER,
    latitube2   DOUBLE,
    longitube2  DOUBLE,
    message_id2 INTEGER
);